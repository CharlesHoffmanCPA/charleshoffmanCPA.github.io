 $(function() {
	
	$("[id^=component-accordion]").each(function() {
		var accordionDiv = $(this);
		$(accordionDiv).find(".network").each(function( index ) {
			var classList = $(this).find('.component-border').get(0).className.split(/\s+/);
			for (var i = 0; i < classList.length; i++) {
			   if (classList[i].indexOf('network-group-') == 0) {
				 //do something
				 var section = classList[i].substring(14);
				 
				 if($(accordionDiv).find('#component-group-' + section).length == 0){
					$('<h3 class="head">' + section.substring(0, 1).toUpperCase() + section.substring(1).replace(/_/g, ' ') + '</h3><div id="component-group-' + section + '"></div>').insertBefore($(accordionDiv).find('[id^=component-group-all-header]'));
				 }
				 
				 $(accordionDiv).find('#component-group-' + section).append($(this).clone());
			   }
			}
			
			 var errors = $(this).find('img[src="css/images/cross.gif"]').length + $(this).find('img[src="/static/css/images/cross.gif"]').length;
			 var warnings = $(this).find('img[src="css/images/warning.gif"]').length + $(this).find('img[src="/static/css/images/warning.gif"]').length;			 
			 
			 if(errors > 0 || warnings > 0){
				if(accordionDiv.children('.component-group-review_Recommended').length == 0){
					$('<h3 class="head">Flagged for Review</h3><div class="component-group-review_Recommended"></div>').insertAfter('.component-group-all');
				}
				accordionDiv.children('.component-group-review_Recommended').append($(this).clone());
			 }
		});
	});
	
	$("[id^=component-accordion] > h3" ).each(function( index ) {
		
		var componenets = $(this).next().find('.network').length;
		$(this).append(' (' + componenets + ')');
		
	});
	
	/*
	$("#component-accordion > h3" ).each(function( index ) {
		
		var errors = $(this).next().find('img[src="css/images/cross.gif"]').length;
		var warnings = $(this).next().find('img[src="css/images/warning.gif"]').length;
		if(errors > 0){
			$(this).append('<span class="badge red">' + errors +'</span>');
		}
		
		if(warnings > 0){
			$(this).append('<span class="badge yellow">' + warnings +'</span>');
		}
	});
	*/
	
    $("[id^=component-accordion]")
      .accordion({
		collapsible: true,
		autoHeight: false,
		heightStyle: "content",
        header: "> h3"
      });
	  
	 $('.component-border').hover(
		function () {
			var classList = this.className.split(/\s+/);
			var section = null;
			for (var i = 0; i < classList.length; i++) {
			   if (classList[i].indexOf('network-group-') == -1 && classList[i].indexOf('network-') == 0) {
				 section = classList[i].substring(8);
			   }
			}
			
			if(section != null){
				var pos = $(this).position();
				var height = $(this).outerHeight();
				var color = $(this).css("background-color");
				var div = $("<div class='component-border-hover-class' id='component-border-hover'> " + section.substring(0, 1).toUpperCase() + section.substring(1).replace(/_/g, ' ').replace(/--/g, '(').replace(/-/g, ')') + "</div>");
				$(this).parent().append($(div).css({
					position: "absolute",
					top: (pos.top + (height / 2)) + "px",
					left: (pos.left + 5) + "px",
					borderColor: color
				}));
			
			}
		},
		
		function () {
			$('#component-border-hover').remove();
		}
		);
  });