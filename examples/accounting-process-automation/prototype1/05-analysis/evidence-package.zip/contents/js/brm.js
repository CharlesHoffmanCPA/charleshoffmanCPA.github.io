$(function() {
	$( "#content #radio").buttonset();
	bindEvents();
	
});


function showConcept(conceptId){
	
    var _url = "report-elements/" + conceptId + ".html .content-block";
	popUp(_url, "770px", "770px", "50%", "75%", 0.4);
    //$.colorbox({href:_url, width:"770px", minHeight:"50%", maxHeight:"75%", opacity:0.4 });
}

function showPopup(_url){
	popUp(_url, "50%", "800px", "50%", "75%", 0.4);
    //$.colorbox({href:_url + ' .content-block', minWidth:"50%", minHeight:"50%", maxWidth:"800px", maxHeight:"75%", opacity:0.4});
}

function showFact(factId){
    var _url = "facts/" + factId + ".html  .content-block";
	popUp(_url, "50%", "800px", "50%", "75%", 0.4);
    //$.colorbox({href:_url, minWidth:"50%", minHeight:"50%", maxWidth:"800px", maxHeight:"75%", opacity:0.4});
}

function showStatic(link){
	var _url = link;
	if(document.URL.indexOf("file://") == 0){
		_url = "https://www.xbrlcloud.com" + link;
	}
	
	window.open(_url, '_blank');
	window.focus();
}

function popUp(_url, _minWidth, _maxWidth, _minHeight, _maxHeight, _opacity){
	//alert(window.navigator.userAgent);
	if(window.navigator.userAgent.indexOf("Chrome") > -1 && document.URL.indexOf("file://") == 0){
		var _purl = _url;
		if(_purl.indexOf(" ") > -1){
			_purl = _purl.substring(0, _purl.indexOf(" "));
		}
		window.open(_purl, "popup", "height=500,width=730,location=no,toolbar=no");
	}else{
		$.colorbox({href:_url, minWidth: _minWidth, minHeight: _minHeight, maxWidth: _maxWidth, maxHeight: _maxHeight, opacity: _opacity });
	}
}


function bindEvents(){
	if($('#showAllElementLabels')){
		$('#showAllElementLabels').click(function(){
			$(".label-mismatch").show();
		});
	}
	
	if($('#showOnlyElementLabelDifferences')){
		$('#showOnlyElementLabelDifferences').click(function(){
			$(".label-mismatch").hide();
		});
	}
}

function getURLParameter(name) {
	return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20'))||null;
}

function toggle(id){
    if($('#did-' + id).is(':visible')){
        $('#did-' + id).hide();
        $('#iid-' + id).attr('src', 'https://www.xbrlcloud.com/images/expand.gif');
    }else{
        $('#did-' + id).show();
        $('#iid-' + id).attr('src', 'https://www.xbrlcloud.com/images/collapse.gif');
    }
}