$(function() {
	$("table.detail-table tr:nth-child(even)").addClass("even");
	$("table.fact-table tr td:first-child").addClass("fact-first");
	$("table.component-table tr td:first-child").addClass("component-first");
	
	$("table.verification-table-component tr:nth-child(even)").addClass("even");

	$("table.verification-table tr th:nth-child(n+4)").addClass("fact-first");
	$("table.verification-table tr th:nth-child(-n+3)").addClass("grey-background");

	$("table.verification-table-component tr th:nth-child(n+4)").addClass("fact-first");
	$("table.verification-table-component tr th:nth-child(-n+3)").addClass("grey-background");


});