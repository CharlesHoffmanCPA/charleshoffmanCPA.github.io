
var dmNetworks;
var epNetworks;
var epConcepts;
var curDisclosue;

$(function() {
	$( "a:has(code)" ).attr('target','_blank').attr('style', 'text-decoration: none;');
	$('#disclosure-table tr td:nth-child(2) span, #disclosure-table tr td:nth-child(7) span').each(function() {

			$(this).click(function(){
				var prefix = $(this).hasClass('dcfound') ? '#tr-' : "#def-";
				$(prefix + $(this).closest('tr').attr('id')).dialog({
				  modal: true,
				  width: 700,
				  buttons: {
					Ok: function() {
					  $( this ).dialog( "close" );
					}
				  }
				});	
			});
	});
	
	$("#radioShowAll").prop("checked", true)
	$('#chkShowLevel1And2').removeAttr('checked');
	
	$('input[type=radio][name=radioShow]').change(function(){
		if($("#radioShowInConsistencies").prop("checked")) {
			$('#disclosure-table tr').each(function(index){
				if($(this).text().indexOf('INCONSISTENT') == -1 && index > 0){
					$(this).hide();
				}else{
					$(this).show();
				}	
				
			});
			
			destroyTree();
		}else if($("#radioShowConsistencies").prop("checked")) {
			$('#disclosure-table tr td:nth-child(8)').each(function(index){
				if($(this).text() == 'CONSISTENT'){
					$(this).parent().show();
				}else{
					$(this).parent().hide();
				}
			});
			
			destroyTree();
		}else if($("#radioShowNotReported").prop("checked")) {
			$('#disclosure-table tr td:nth-child(7)').each(function(index){
				if($(this).text() == 'False' && $(this).next().text().indexOf('INCONSISTENT') == -1){
					$(this).parent().show();
				}else{
					$(this).parent().hide();					
				}
				
			});
			
			destroyTree();
		}else if($("#radioShowReported").prop("checked")) {
			$('#disclosure-table tr td:nth-child(7)').each(function(index){
				if($(this).text() == 'True' || $(this).next().text().indexOf('INCONSISTENT') > -1){
					$(this).parent().show();
				}else{
					$(this).parent().hide();					
				}
				
			});
			
			destroyTree();
		}else{
			$('#disclosure-table tr').show();
			createTree();			
		}
	});
	
	
	$('#chkShowLevel1And2').change(function(){
		if($(this).is(":checked")) {
			$('#disclosure-table td:nth-child(11), #disclosure-table th:nth-child(11)').show();
			$('#disclosure-table td:nth-child(12), #disclosure-table th:nth-child(12)').show();
		}else{
			$('#disclosure-table td:nth-child(11), #disclosure-table th:nth-child(11)').hide();
			$('#disclosure-table td:nth-child(12), #disclosure-table th:nth-child(12)').hide();			
		}
	});
	
	$( "#chkShowLevel1And2" ).trigger( "change" );	
	
	
	$(document.body).on("click", ".ui-widget-overlay", function(){
        $.each($(".ui-dialog"), function(){
            var $dialog;
            $dialog = $(this).children(".ui-dialog-content");
            if($dialog.dialog("option", "modal")){
                $dialog.dialog("close");
            }
        });
    });
	
	createTree();
	
	
	$('.nav-tabs a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
	  var target = $(e.target).attr("href") // activated tab
	  if(target == '#report'){
		  $('#report-container').show();  
		  $('#checklist-container').hide();
		  $('#asfiled-container').hide();
	  }else if(target == '#checklist'){
		  $('#report-container').hide();  
		  $('#checklist-container').show();
		  $('#asfiled-container').hide();
	  }else{
		  $('#report-container').hide();  
		  $('#checklist-container').hide();
		  $('#asfiled-container').show();
	  }
	});
	
	
	
	
	var loc = window.location.href;
	var dir = loc.substring(0, loc.lastIndexOf('/'));
	
	$.getJSON(dir + "/mappings/networks.json", function(json){
		epNetworks = json;
		
		
		$.getJSON(dir + "/mappings/concepts.json", function(json){
		epConcepts = json;
		
			$.getJSON(dir + "/mappings/dm-networks.json", function(json){
				dmNetworks = json;
				initAsFiled();
			});
		});	
	});
	
	
	
	$('#if-l3').on("load", function() {
		iFrameOnLoadL3(this);
	});
	
	$('#if-l4').on("load", function() {
		iFrameOnLoadL4(this);
	});
	
	$('#if-c1').on("load", function() {
		iFrameOnLoadL3(this);
	});
	
	$('#if-c2').on("load", function() {
		iFrameOnLoadL4(this);
	});
	
});

function createTree(){
	$('.tree').treegrid({
		expanderExpandedClass: 'treegrid-expander-expanded',
		expanderCollapsedClass: 'treegrid-expander-collapsed'
		});
}

function destroyTree(){
	$('.tree span').each(function(){
		if($(this).attr('class') != null && $(this).attr('class').includes('treegrid')){
			$(this).remove();
		}	
	});
}

function initAsFiled(){
	$('#asfiled-container').css({'height':(($(window).height())-30)+'px'});
	$('#if-l3').css({'height':(($(window).height())-180)+'px'});
	$('#if-l4').css({'height':(($(window).height())-180)+'px'});
	
	$('#if-c1').css({'height':(($(window).height())-180)+'px'});
	$('#if-c2').css({'height':(($(window).height())-180)+'px'});
	
	$.each(dmNetworks, function(key,value){
		var color;
		var aStyle = '';
		if(value.status.indexOf('CONSISTENT') == -1){
			color = 'grey';
			//aStyle = 'color: grey;';
		}else if(value.status == 'CONSISTENT'){
			color = 'green';
		}else{
			color = 'orange';
		}		
		
		if(value.child){
			aStyle += 'padding-left:50px;';
		}	
				
		$("#checklist-container .nav-sidebar" ).append( "<li role='presentation'><div class='status-icon bg-" + color + "'/><a href='" + key + "' aria-controls='home' role='tab' data-toggle='tab' style='" + aStyle + "'>"
		+ key + '. ' + value.label +  "</a></li>");
	});
	
	$('#checklist-container .nav-sidebar a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
	  var target = $(e.target).attr("href") // activated tab
	  loadNetworks(target);
	});
	
	$($('#checklist-container .nav-sidebar a[data-toggle="tab"]')[0]).trigger("click");
	
	
	var lChild;
	var addedMissingRequiredDisclosure = false;
	$.each(dmNetworks, function(key,value){
		if(value.l3Network == null && value.l4Network == null && value.status == 'INCONSISTENT'){
			if(!addedMissingRequiredDisclosure){
				addedMissingRequiredDisclosure = true;
				var eParent = $("<div class='status-icon bg-purple' style='margin-left: 5px;border-bottom:none;'/><li role='presentation'><a href='' aria-controls='home' role='tab' data-toggle='tab' style='font-weight:bold; padding-left: 22px;'>Required disclosures not provided"
				+ "</a></li>");
				$("#asfiled-container .nav-sidebar" ).append(eParent);
			}	
			
			lChild = $("<div class='status-icon bg-orange' style='margin-left: 20px;'/><li role='presentation' style='border-bottom:none;'><a href='" + key + "' aria-controls='home' role='tab' data-toggle='tab' style='padding-left: 40px;'>Rule: " 
			+ value.label + "</a></li>");
			$("#asfiled-container .nav-sidebar" ).append(lChild);
		}
	});	
	
	$.each(epNetworks, function(key,value){
		if(key == 'http://www.xbrl.org/2003/role/link~xbrl:impliedTable'){
			return;
		}	
		
		
				
		var eParent = $("<div class='status-icon bg-purple' style='margin-left: 5px;'/><li role='presentation'><a href='" + value.id + "' aria-controls='home' role='tab' data-toggle='tab' style='font-weight:bold; padding-left: 22px;'>Component: "
		+ value.networkLabel + (value.tableLabel == null ? "" : " | "  + value.tableLabel) +  "</a></li>");
		$("#asfiled-container .nav-sidebar" ).append(eParent);
		
		
		$.each(dmNetworks, function(key1,value1){
			if(value1.l3Network == key || value1.l4Network == key){
				var color;
				
				if(value1.status.indexOf('CONSISTENT') == -1){
					color = 'grey';
					//aStyle = 'color: grey;';
				}else if(value1.status == 'CONSISTENT'){
					color = 'green';
				}else{
					color = 'orange';
				}
				
				lChild = $("<div class='status-icon bg-" + color + "' style='margin-left: 20px;'/><li role='presentation' style='border-bottom:none;'><a href='" + key1 + "' aria-controls='home' role='tab' data-toggle='tab' style='padding-left: 40px;'>Rule: " + value1.label + "</a></li>");
				$("#asfiled-container .nav-sidebar" ).append(lChild);
			}	
		});	
		
		if(lChild != null){
			lChild.css('border-bottom', '1px solid #7e7e7e');
			eParent.css('border-bottom', 'none');
		}	
		//$("#asfiled-container .nav-sidebar" ).append(sHtml + "</li>");
	});
	
	$('#asfiled-container .nav-sidebar a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
	  var target = $(e.target).attr("href") // activated tab
	  if(target.substr(0, 1) == 'N'){
		loadNetwork(target);
	  }else{
		loadComponents(target);  
	  } 	  
	});
	
	$($('#asfiled-container .nav-sidebar a:contains("Component: ")')[0]).trigger("click");
	
}


function loadNetworks(target){
	curDisclosue = dmNetworks[target];
	var l3Uri = dmNetworks[target].l3Network;
	var l4Uri = dmNetworks[target].l4Network;

	var loc = window.location.href;
	var dir = loc.substring(0, loc.lastIndexOf('/'));

	if(l3Uri == null){
		$('#if-l3').attr('src', '');  
	}else{
		$('#if-l3').attr('src', dir + '/Rendering-' + epNetworks[l3Uri].id + '.html');  
		$('#div-l3').show();
	}	

	if(l4Uri == null){
		$('#if-l4').attr('src', '');  
		$('#div-l4').hide();
	}else{
		$('#if-l4').attr('src', dir + '/Rendering-' + epNetworks[l4Uri].id + '.html');  
	}	

	if(l3Uri == null && l4Uri == null){
	}else if(l3Uri == null ){
		$('#div-l3').hide();
		$('#div-l4').show();
		$('#div-l4').attr("class","col-md-12");	
	}else if(l4Uri == null ){
		$('#div-l4').hide();
		$('#div-l3').show();
		$('#div-l3').attr("class","col-md-12");	
	}else{
		$('#div-l4').show();
		$('#div-l3').show();
		$('#div-l3').attr("class","col-md-6");	
		$('#div-l4').attr("class","col-md-6");	
	}		

	$('#component-desc').html('Representation Concept [TEXT BLOCK]: <b>' + dmNetworks[target].l3Label + '</b>, Representation Concept [DETAIL]: <b>' + dmNetworks[target].l4Label + '</b>')	
	$('#reason').text('Reason: ' + dmNetworks[target].reason);
}	


function loadNetwork(target){
	$('#asfiled-container .well').hide();
	curDisclosue = null;
	var loc = window.location.href;
	var dir = loc.substring(0, loc.lastIndexOf('/'));

	$('#if-c2').attr('src', '');  
	$('#div-c2').hide();
	$('#div-c1').attr("class","col-md-12");	
	
	if(target == null){
		$('#if-c1').attr('src', '');  
	}else{
		$('#if-c1').attr('src', dir + '/Rendering-' + target + '.html');  
		$('#div-c1').show();
	}	
}	

function loadComponents(target){
	$('#div-c1').hide();
	$('#div-c2').hide();
	$('#asfiled-container .well').hide();
	
	if(target == ''){
	   return;		
	}	
	
	curDisclosue = dmNetworks[target];
	
	
	var l3Uri = dmNetworks[target].l3Network;
	var l4Uri = dmNetworks[target].l4Network;

	var loc = window.location.href;
	var dir = loc.substring(0, loc.lastIndexOf('/'));

	if(l3Uri == null){
		$('#if-c1').attr('src', '');  
	}else{
		$('#if-c1').attr('src', dir + '/Rendering-' + epNetworks[l3Uri].id + '.html');  
		$('#div-c1').show();
	}	

	if(l4Uri == null){
		$('#if-c2').attr('src', '');  
	}else{
		$('#if-c2').attr('src', dir + '/Rendering-' + epNetworks[l4Uri].id + '.html');  
	}	

	if(l3Uri == null && l4Uri == null){
	}else if(l3Uri == null ){
		$('#div-c2').show();
		$('#div-c2').attr("class","col-md-12");	
	}else if(l4Uri == null ){
		$('#div-c1').show();
		$('#div-c1').attr("class","col-md-12");	
	}else{
		$('#div-c2').show();
		$('#div-c1').show();
		$('#div-c1').attr("class","col-md-6");	
		$('#div-c2').attr("class","col-md-6");	
	}		

	$('#component-desc1').html('Representation Concept [TEXT BLOCK]: <b>' + dmNetworks[target].l3Label + '</b>, Representation Concept [DETAIL]: <b>' + dmNetworks[target].l4Label + '</b>')	
	$('#reason1').text('Reason: ' + dmNetworks[target].reason);
	$('#asfiled-container .well').show();
}	

function iFrameOnLoadL3(iFrame){
	if(curDisclosue == null){
		return;
	}	
	
	if($(iFrame).attr('src') != ''){
		var headings = $(iFrame).contents().find('h2');
		if(headings.length > 0){
			$(headings[0]).html('Representation Concept [TEXT BLOCK] ' + $(headings[0]).html());
		}
		
		if(curDisclosue.l3Concept != null){
			var dcid = epConcepts[curDisclosue.l3Concept];
			if(dcid != null){
				
				var showTr;
				$($(iFrame).contents().find("td[class*='rendering-member'] a")).each(function(){
					var cid = $(this).attr('href').replace(/[^\']*/, '').replace(/[\')]/g, '');
					if(cid == dcid){
						showTr = $(this).closest('tr');
					}	
					
				});
				
				if(showTr != null){
					$(iFrame).contents().find("table[class*='rendering-table'] tr").each(function(){
						if($(this).find("td[class*='rendering-member']").length == 0 ){
							return;
						}	
						
						if($(this).html().indexOf("('" + dcid + "')") == -1){
							$(this).hide();
						}	
						
					});
				}	
				
			}	
		}	
	}	
}

function iFrameOnLoadL4(iFrame){
	if(curDisclosue == null){
		return;
	}
	
	if($(iFrame).attr('src') != ''){
		var headings = $(iFrame).contents().find('h2');
		if(headings.length > 0){
			$(headings[0]).html('Representation Concept [DETAIL] ' + $(headings[0]).html());
		}
	}	
}
